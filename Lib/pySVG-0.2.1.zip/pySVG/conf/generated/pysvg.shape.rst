.. AUTO-GENERATED FILE -- DO NOT EDIT!

shape
=====

Module: :mod:`shape`
--------------------
Inheritance diagram for ``pysvg.shape``:

.. inheritance-diagram:: pysvg.shape 
   :parts: 3

.. automodule:: pysvg.shape

.. currentmodule:: pysvg.shape

Classes
-------

:class:`circle`
~~~~~~~~~~~~~~~


.. autoclass:: circle
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`ellipse`
~~~~~~~~~~~~~~~~


.. autoclass:: ellipse
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`line`
~~~~~~~~~~~~~


.. autoclass:: line
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`path`
~~~~~~~~~~~~~


.. autoclass:: path
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`polygon`
~~~~~~~~~~~~~~~~


.. autoclass:: polygon
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`polyline`
~~~~~~~~~~~~~~~~~


.. autoclass:: polyline
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`rect`
~~~~~~~~~~~~~


.. autoclass:: rect
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
