.. AUTO-GENERATED FILE -- DO NOT EDIT!

parser
======

Module: :mod:`parser`
---------------------
.. automodule:: pysvg.parser

.. currentmodule:: pysvg.parser

Functions
---------


.. autofunction:: pysvg.parser.build


.. autofunction:: pysvg.parser.calculateMethodName


.. autofunction:: pysvg.parser.parse


.. autofunction:: pysvg.parser.setAttributes

