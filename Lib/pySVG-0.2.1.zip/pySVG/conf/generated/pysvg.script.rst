.. AUTO-GENERATED FILE -- DO NOT EDIT!

script
======

Module: :mod:`script`
---------------------
Inheritance diagram for ``pysvg.script``:

.. inheritance-diagram:: pysvg.script 
   :parts: 3

.. automodule:: pysvg.script

.. currentmodule:: pysvg.script

:class:`script`
---------------


.. autoclass:: script
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
