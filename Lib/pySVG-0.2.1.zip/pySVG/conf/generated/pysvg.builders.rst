.. AUTO-GENERATED FILE -- DO NOT EDIT!

builders
========

Module: :mod:`builders`
-----------------------
Inheritance diagram for ``pysvg.builders``:

.. inheritance-diagram:: pysvg.builders 
   :parts: 3

.. automodule:: pysvg.builders

.. currentmodule:: pysvg.builders

Classes
-------

:class:`ShapeBuilder`
~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: ShapeBuilder
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`StyleBuilder`
~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: StyleBuilder
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`TransformBuilder`
~~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: TransformBuilder
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
