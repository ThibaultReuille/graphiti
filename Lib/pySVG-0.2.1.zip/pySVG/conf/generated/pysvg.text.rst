.. AUTO-GENERATED FILE -- DO NOT EDIT!

text
====

Module: :mod:`text`
-------------------
Inheritance diagram for ``pysvg.text``:

.. inheritance-diagram:: pysvg.text 
   :parts: 3

.. automodule:: pysvg.text

.. currentmodule:: pysvg.text

Classes
-------

:class:`altGlyph`
~~~~~~~~~~~~~~~~~


.. autoclass:: altGlyph
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`altGlyphDef`
~~~~~~~~~~~~~~~~~~~~


.. autoclass:: altGlyphDef
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`altGlyphItem`
~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: altGlyphItem
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`glyphRef`
~~~~~~~~~~~~~~~~~


.. autoclass:: glyphRef
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`text`
~~~~~~~~~~~~~


.. autoclass:: text
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`textPath`
~~~~~~~~~~~~~~~~~


.. autoclass:: textPath
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`tref`
~~~~~~~~~~~~~


.. autoclass:: tref
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`tspan`
~~~~~~~~~~~~~~


.. autoclass:: tspan
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
