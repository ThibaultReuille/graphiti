.. AUTO-GENERATED FILE -- DO NOT EDIT!

animate
=======

Module: :mod:`animate`
----------------------
Inheritance diagram for ``pysvg.animate``:

.. inheritance-diagram:: pysvg.animate 
   :parts: 3

.. automodule:: pysvg.animate

.. currentmodule:: pysvg.animate

Classes
-------

:class:`AnimationAdditionAttrib`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: AnimationAdditionAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`AnimationAttrib`
~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: AnimationAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`AnimationAttributeAttrib`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: AnimationAttributeAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`AnimationEventsAttrib`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: AnimationEventsAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`AnimationTimingAttrib`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: AnimationTimingAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`AnimationValueAttrib`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: AnimationValueAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`animate`
~~~~~~~~~~~~~~~~


.. autoclass:: animate
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`animateColor`
~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: animateColor
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`animateMotion`
~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: animateMotion
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`animateTransform`
~~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: animateTransform
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`mpath`
~~~~~~~~~~~~~~


.. autoclass:: mpath
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`set`
~~~~~~~~~~~~


.. autoclass:: set
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
