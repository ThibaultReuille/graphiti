.. AUTO-GENERATED FILE -- DO NOT EDIT!

linking
=======

Module: :mod:`linking`
----------------------
Inheritance diagram for ``pysvg.linking``:

.. inheritance-diagram:: pysvg.linking 
   :parts: 3

.. automodule:: pysvg.linking

.. currentmodule:: pysvg.linking

Classes
-------

:class:`a`
~~~~~~~~~~


.. autoclass:: a
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`view`
~~~~~~~~~~~~~


.. autoclass:: view
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
