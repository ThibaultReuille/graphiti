.. AUTO-GENERATED FILE -- DO NOT EDIT!

core
====

Module: :mod:`core`
-------------------
Inheritance diagram for ``pysvg.core``:

.. inheritance-diagram:: pysvg.core 
   :parts: 3

.. automodule:: pysvg.core

.. currentmodule:: pysvg.core

Classes
-------

:class:`BaseElement`
~~~~~~~~~~~~~~~~~~~~


.. autoclass:: BaseElement
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`BaseShape`
~~~~~~~~~~~~~~~~~~


.. autoclass:: BaseShape
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`DeltaPointAttrib`
~~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: DeltaPointAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`DimensionAttrib`
~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: DimensionAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`PointAttrib`
~~~~~~~~~~~~~~~~~~~~


.. autoclass:: PointAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`PointToAttrib`
~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: PointToAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`RotateAttrib`
~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: RotateAttrib
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`TextContent`
~~~~~~~~~~~~~~~~~~~~


.. autoclass:: TextContent
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
