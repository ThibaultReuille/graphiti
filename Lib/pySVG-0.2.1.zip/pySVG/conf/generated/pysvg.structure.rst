.. AUTO-GENERATED FILE -- DO NOT EDIT!

structure
=========

Module: :mod:`structure`
------------------------
Inheritance diagram for ``pysvg.structure``:

.. inheritance-diagram:: pysvg.structure 
   :parts: 3

.. automodule:: pysvg.structure

.. currentmodule:: pysvg.structure

Classes
-------

:class:`clipPath`
~~~~~~~~~~~~~~~~~


.. autoclass:: clipPath
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`defs`
~~~~~~~~~~~~~


.. autoclass:: defs
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`desc`
~~~~~~~~~~~~~


.. autoclass:: desc
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`g`
~~~~~~~~~~


.. autoclass:: g
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`image`
~~~~~~~~~~~~~~


.. autoclass:: image
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`metadata`
~~~~~~~~~~~~~~~~~


.. autoclass:: metadata
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`svg`
~~~~~~~~~~~~


.. autoclass:: svg
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`switch`
~~~~~~~~~~~~~~~


.. autoclass:: switch
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`symbol`
~~~~~~~~~~~~~~~


.. autoclass:: symbol
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`title`
~~~~~~~~~~~~~~


.. autoclass:: title
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`use`
~~~~~~~~~~~~


.. autoclass:: use
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
