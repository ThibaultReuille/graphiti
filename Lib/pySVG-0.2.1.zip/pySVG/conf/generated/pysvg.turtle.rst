.. AUTO-GENERATED FILE -- DO NOT EDIT!

turtle
======

Module: :mod:`turtle`
---------------------
Inheritance diagram for ``pysvg.turtle``:

.. inheritance-diagram:: pysvg.turtle 
   :parts: 3

.. automodule:: pysvg.turtle

.. currentmodule:: pysvg.turtle

Classes
-------

:class:`Turtle`
~~~~~~~~~~~~~~~


.. autoclass:: Turtle
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`Vector`
~~~~~~~~~~~~~~~


.. autoclass:: Vector
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
