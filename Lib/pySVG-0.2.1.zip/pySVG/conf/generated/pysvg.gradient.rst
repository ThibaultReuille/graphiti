.. AUTO-GENERATED FILE -- DO NOT EDIT!

gradient
========

Module: :mod:`gradient`
-----------------------
Inheritance diagram for ``pysvg.gradient``:

.. inheritance-diagram:: pysvg.gradient 
   :parts: 3

.. automodule:: pysvg.gradient

.. currentmodule:: pysvg.gradient

Classes
-------

:class:`linearGradient`
~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: linearGradient
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`pattern`
~~~~~~~~~~~~~~~~


.. autoclass:: pattern
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`radialGradient`
~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: radialGradient
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__

:class:`stop`
~~~~~~~~~~~~~


.. autoclass:: stop
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
