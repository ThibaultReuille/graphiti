.. AUTO-GENERATED FILE -- DO NOT EDIT!

style
=====

Module: :mod:`style`
--------------------
Inheritance diagram for ``pysvg.style``:

.. inheritance-diagram:: pysvg.style 
   :parts: 3

.. automodule:: pysvg.style

.. currentmodule:: pysvg.style

:class:`style`
--------------


.. autoclass:: style
  :members:
  :undoc-members:
  :show-inheritance:
  :inherited-members:

  .. automethod:: __init__
