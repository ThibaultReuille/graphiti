.. AUTO-GENERATED FILE -- DO NOT EDIT!

.. toctree::

   generated\pysvg.animate
   generated\pysvg.attributes
   generated\pysvg.builders
   generated\pysvg.core
   generated\pysvg.filter
   generated\pysvg.gradient
   generated\pysvg.linking
   generated\pysvg.parser
   generated\pysvg.script
   generated\pysvg.shape
   generated\pysvg.structure
   generated\pysvg.style
   generated\pysvg.text
