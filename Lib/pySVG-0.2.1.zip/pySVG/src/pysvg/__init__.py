#__all__ = []
#for subpackage in ['core', 'filter', 'gradient', 'linking', 'script','shape','structure','style','text']:
#    try: 
#        exec 'import ' + subpackage
#        __all__.append( subpackage )
#    except ImportError:
#        pass



    
 
    
    